                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1016479
MiniPlan v5.0 by ShinWeiChiou is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

http://www.MiniPlan.co  (New site launched, special offer trending)

Update NOTE!!  I've made MiniPlan V5.1 and now MIniPlan has its own Facebook page:

V5.1 on Thingivers:  http://www.thingiverse.com/thing:1230335
MiniPlan - Robot Fun: https://www.facebook.com/miniPlanrobot/


____________________________________________________________________
The MiniPlan v5.0 is more smaller and more cheap !  
https://www.facebook.com/miniPlanrobot/

Control Board : TOROBOT USC-20 & Bluetooth UATR to TTL  
http://tw.taobao.com/item/45065229005.htm  
http://tw.taobao.com/item/10194716671.htm  

Servo : Emax ES08DE or Emax ES08MD  x 16 PCS ( +1 for Head )  
http://www.amazon.com/Emax-ES08DE-Digital-Helicopters-Airplanes/dp/B00C85NPF2  

Power Board : LM2596 DC-DC Buck Converter Step Down Module  
Battery : DUALSKY 7.4V , 400mAh  
Screws : M2 x 5mm , M2 x 8mm , M3 x 6mm  
Bearing : 4x7x2.5 MR74ZZ  


This had always been a dream since I was little,  
it's the 3D printers that allowed my dream to come true。  
There are 16 servo motors that operated MiniPlan and performing different actions.  
I used Rhinoceros to draw the mechanical parts and Arduino IDE to code the firmware.  
I'm using Prusa i3 along with PLA.  
The whole set took about 18~24 hours to complete.  
The axles for the servo motor are not 3D printed because our 3D printer does not have the precision to print this.  


I'm from Taiwan and English not well.  
But I try my best answer your question.  
Thank you ~ ^_^  

# Instructions

Assembly Instruction :  
https://www.youtube.com/watch?v=iYPJHKjJyGM 

http://www.thingiverse.com/thing:1040994

Use PLA  ( total need about 300g )  
MiniPlan5_40 Fill Density 30% & use Support  
MiniPlan5_50 & 51 Fill Density 50%  
Other Parts Fill Density 50% ~ 100%  

Head Parts List :  
MiniPlan5_40 x1  
MiniPlan5_42 x1  
MiniPlan5_43 x1  
or   
MiniPlan5_40 x1  
MiniPlan5_41 x1  

Body Parts List :  
MiniPlan5_10 x2  
MiniPlan5_30 x1  
MiniPlan5_31(A or B) x1  
MiniPlan5_33 x1 (for TOROBOT USC-20 Control Board)  
or  
MiniPlan5_32 x1 (for Other Control Board)  
MiniPlan5_34 x1  

Arms Parts List :  
MiniPlan5_10 x4  
MiniPlan5_14 x2  
MiniPlan5_20 x4  
MiniPlan5_21 x4  
MiniPlan5_23 x2  
MiniPlan5_50 x1 (Left)  
MiniPlan5_51 x1 (Right)  

Legs Parts List :  
MiniPlan5_10 x8  
MiniPlan5_11 x6  
MiniPlan5_12 x1 (Right)  
MiniPlan5_13 x1 (Left)  
MiniPlan5_20 x4  
MiniPlan5_21 x4  
MiniPlan5_22 x4  
MiniPlan5_24 x2  
MiniPlan5_25 x2  
MiniPlan5_26 x2  
MiniPlan5_27 x2  
MiniPlan5_60 x1 (Left)  
MiniPlan5_61 x1 (Right)